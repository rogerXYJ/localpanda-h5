import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _7b5de475 = () => import('..\\pages\\wx\\getcode.vue' /* webpackChunkName: "pages_wx_getcode" */).then(m => m.default || m)
const _0df2721c = () => import('..\\pages\\info\\feedback\\index.vue' /* webpackChunkName: "pages_info_feedback_index" */).then(m => m.default || m)
const _948d5790 = () => import('..\\pages\\activity\\payment\\index.vue' /* webpackChunkName: "pages_activity_payment_index" */).then(m => m.default || m)
const _71acff14 = () => import('..\\pages\\info\\inquiry\\index.vue' /* webpackChunkName: "pages_info_inquiry_index" */).then(m => m.default || m)
const _692b6ee8 = () => import('..\\pages\\travel\\expats\\index.vue' /* webpackChunkName: "pages_travel_expats_index" */).then(m => m.default || m)
const _d59d2506 = () => import('..\\pages\\activity\\detail.vue' /* webpackChunkName: "pages_activity_detail" */).then(m => m.default || m)
const _0e85722b = () => import('..\\pages\\activity\\payment\\wxMobilePay.vue' /* webpackChunkName: "pages_activity_payment_wxMobilePay" */).then(m => m.default || m)
const _21c648c0 = () => import('..\\pages\\user\\bookings\\entry.vue' /* webpackChunkName: "pages_user_bookings_entry" */).then(m => m.default || m)
const _6005a12e = () => import('..\\pages\\activity\\payment\\success.vue' /* webpackChunkName: "pages_activity_payment_success" */).then(m => m.default || m)
const _4a85a822 = () => import('..\\pages\\travel\\expats\\details\\_theme.vue' /* webpackChunkName: "pages_travel_expats_details__theme" */).then(m => m.default || m)
const _2750c7e4 = () => import('..\\pages\\activity\\details\\_id.vue' /* webpackChunkName: "pages_activity_details__id" */).then(m => m.default || m)
const _6b305fb0 = () => import('..\\pages\\activity\\list\\_slug.vue' /* webpackChunkName: "pages_activity_list__slug" */).then(m => m.default || m)
const _f63ec8a6 = () => import('..\\pages\\activity\\booking\\_id.vue' /* webpackChunkName: "pages_activity_booking__id" */).then(m => m.default || m)
const _957cee44 = () => import('..\\pages\\activity\\check\\_id.vue' /* webpackChunkName: "pages_activity_check__id" */).then(m => m.default || m)
const _76f7bef6 = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/wx/getcode",
			component: _7b5de475,
			name: "wx-getcode"
		},
		{
			path: "/info/feedback",
			component: _0df2721c,
			name: "info-feedback"
		},
		{
			path: "/activity/payment",
			component: _948d5790,
			name: "activity-payment"
		},
		{
			path: "/info/inquiry",
			component: _71acff14,
			name: "info-inquiry"
		},
		{
			path: "/travel/expats",
			component: _692b6ee8,
			name: "travel-expats"
		},
		{
			path: "/activity/detail",
			component: _d59d2506,
			name: "activity-detail"
		},
		{
			path: "/activity/payment/wxMobilePay",
			component: _0e85722b,
			name: "activity-payment-wxMobilePay"
		},
		{
			path: "/user/bookings/entry",
			component: _21c648c0,
			name: "user-bookings-entry"
		},
		{
			path: "/activity/payment/success",
			component: _6005a12e,
			name: "activity-payment-success"
		},
		{
			path: "/travel/expats/details/:theme?",
			component: _4a85a822,
			name: "travel-expats-details-theme"
		},
		{
			path: "/activity/details/:id?",
			component: _2750c7e4,
			name: "activity-details-id"
		},
		{
			path: "/activity/list/:slug?",
			component: _6b305fb0,
			name: "activity-list-slug"
		},
		{
			path: "/activity/booking/:id?",
			component: _f63ec8a6,
			name: "activity-booking-id"
		},
		{
			path: "/activity/check/:id?",
			component: _957cee44,
			name: "activity-check-id"
		},
		{
			path: "/",
			component: _76f7bef6,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
